package map;

public class Edge {
    public double length;
    public double crowding;
    public boolean bikePermission;
}
